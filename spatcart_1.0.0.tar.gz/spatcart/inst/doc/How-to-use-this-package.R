## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(spatcart)

## ---- message=FALSE-----------------------------------------------------------
library(spatstat)
ypp = ants
ypp

## ---- message=FALSE, fig.width=5, fig.align="center"--------------------------
library(dplyr)
library(ggplot2)
major =  names(which.max(intensity(ypp)))
minor = names(which.min(intensity(ypp)))

K0 = Kcross(ypp, major, minor, correction="none")
K01 = tibble(
    scale = K0$r,
    difference = K0$un-K0$theo
    )
ggplot(K01, aes(x=scale, y=difference))+geom_line()+xlab("r")+
  ylab("Kest - Ktheo")+
  ggtitle("Difference between estimated and theoretical K")+
  theme(axis.title.x = element_text(size=14))+
  theme(axis.title.y = element_text(size=14))+
  theme(plot.title = element_text(hjust = 0.5, size=14))

## -----------------------------------------------------------------------------
zone = which(K0$r>=150 & K0$r<=170)
r1 = K0$r[zone]
r0 = r1[which.min((K0$un-K0$theo)[zone])]
r0

## ---- fig.width = 4.5, fig.height = 3.25, fig.align="center"------------------
t = spatcart(ypp, r0)

## -----------------------------------------------------------------------------
tmax = spattree(ypp, r0)

## ---- fig.width=4.5, fig.align="center"---------------------------------------
seq = spatprune(tmax$tree)

## ---- fig.width = 4, fig.height = 2.75, fig.align="center"--------------------
K = tmax$K[rownames(tmax$tree$frame)][tmax$tree$frame$var=="<leaf>"]
partition.spattree(tmax$tree, ypp, K)

## ---- out.width='60%', out.width='60%', fig.align="center"--------------------
set.seed(12)
chess = damier(1000)
chess = damier(1000, h=0.45,  model = "Poisson")
repuls = repulsion(1000, 0.05)

## ---- message = FALSE, fig.width = 4, fig.height = 2.75, fig.align="center"----
nuage = data.frame(
    x = chess$data$x1,
    y = chess$data$x2,
    Mark = chess$data$label
    )
library(tree)
tmax = tree(Mark~.,data=nuage,split="gini",model=T, minsize=50,mincut=25)
seq = spatprune(tmax, method = "misclass")
t = seq$opt.tree.min # selects smallest optimal subtree 
nuage %>% ggplot(aes(x,y, color = Mark))+geom_point()+
  scale_color_manual(values = c("blue", "red"))+
  gg.partition.tree(t)+
  labs(x = "", y = "")+
  theme_classic()

## ---- message = FALSE, fig.width = 5, fig.height = 4, fig.align="center"------
Paracou(15)

## ---- message = FALSE, fig.width = 4.5, fig.height = 3.25, fig.align="center"----
ypp = Paracoudata()

# SpatCART trees
t = spatcart(ypp, 15, graph = FALSE)

a = t$opt.tree.min
K = t$K[rownames(a$frame)][a$frame$var=="<leaf>"]

Paracou.plot(a,ypp,K)

